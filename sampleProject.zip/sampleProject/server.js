// Importing modules
const express = require('express');
const app = express();
const f = require('./routes/f');

app.set('view engine','ejs');


// Port
const port = process.env.PORT || 5000;

//Middleware
app.use(express.urlencoded({extended: true}));
app.use(express.json());
app.use('/routes/f',f);


app.listen(port,()=>{
    console.log(`Server started on ${port}`);
});