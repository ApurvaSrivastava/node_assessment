const express=require('express');
const router=express.Router();

   const mongoose=require('mongoose');
   mongoose.connect('mongodb://localhost/university').
   then(()=>console.log('connected to mongoose..')).
   catch(err=>console.log('UNABLE TO CONNECT',err));
   
router.get('/',(req,res)=>{
	res.render('./f');
});

router.post('/',(req,res)=>{
    var user = req.body;
    var name=req.body.name;
    var sid=req.body.sid;
   var age=req.body.age;
  console.log(user);
   const info=new mongoose.Schema({
       name: String,
       age: Number,
       sid: Number
   });
   
     
       const st=new St({
       name: name,
       age: age,
       sid: sid
       });
       const result= st.save();
if(result)
console.log('value saved');
else
console.log('error whikle saving');
   
});
