for (let i=0; i<5; i++) { 
    task(i); 
 } 
   
 function task(i) { 
   setTimeout(function() { 
       console.log(`delayed response ${i+1}`);
   }, 2000 * i); 
 } 