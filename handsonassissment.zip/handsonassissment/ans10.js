var net = require('net');
// Create and return a net.Server object, the function will be invoked when client connect to this server.
var server = net.createServer(function(client) {

    client.on('data', function (data) {

        // Print received client data and length.
        console.log('Receive client send data : ' + data);

        // Server send data back to client use client net.Socket object.
        client.end('Server received data : ' + data);
    });

    // When client send data complete.
    client.on('end', function () {
        console.log('Client disconnect.');
    });
});

server.listen(3000, function() { 
   console.log('server is listening');
});



