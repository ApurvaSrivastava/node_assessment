var fruits = ["Banana", "Orange", "Apple", "Mango"];
console.log("enter fruit name");

process.argv.shift() ; // skip node.exe
process.argv.shift() ; // skip name of js file
const path=require('path');
frt=process.argv.join(" ")

fruits.push(frt);
console.log(fruits);
