process.argv.shift() ; // skip node.exe
process.argv.shift() ; // skip name of js file
const path=require('path');


const fs=require('fs');
path1=path.dirname(process.argv.join(" "));
//console.log(path1);
fs.readdir(path1, function (err, files) {
    //handling error
    if (err) {
        return console.log('Unable to scan directory: ' + err);
    } 
    files.forEach(function (file) {
        console.log(file); 
    });
});
