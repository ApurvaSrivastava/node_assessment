const Course=model.mongoose('Course',courseschema);
async function cc(){
    const course=new Course()
}