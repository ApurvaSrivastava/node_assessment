var request = require("request");
fs = require('fs');

request({
  uri: "http://www.google.com",
}, function(error, response, body) {
  //console.log(body);

  fs.writeFile('demo.txt', body, function (err) {
    if (err) return console.log(err);
    //console.log('Hello World > helloworld.txt');
  });
  
});