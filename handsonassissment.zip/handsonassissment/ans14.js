const mongoose= require('mongoose');
mongoose.connect('mongodb://localhost/university').
then(()=>console.log('connected to mongoose..')).
catch(err=>console.log('UNABLE TO CONNECT',err));

const info=new mongoose.Schema({
    name: String,
    age: Number,
    sid: Number   
});
async function createStu() {
  
    const student=new Student({
    name: 'xyz',
    age: 24,
    sid: 104
    });
    const result= await student.save();
    console.log('new value created');
    console.log(result);
}
createStu();
const Student=new mongoose.model('Student',info);


async function getStudent() {
    const student=await Student.find();
    console.log(student);
}
getStudent();

async function update(){
    const student=await Student.find({sid:101});

    student.sid=1;
    const result=await student.save();
    console.log('updating sid');
    console.log(result);
}
update();

async function del(){
    const result=await Student.deleteOne({sid:100});
    console.log('delete sid with val 100')
   console.log(result);

}
del();