const express = require('express');
const app = express();
const session = require('express-session');
const login = require('./controller/login');
const register = require('./controller/register');

const managerHome = require('./controller/manager/home');
app.use(express.urlencoded({extended: true}));
app.use(express.json());
app.use(session({secret: 'My Scret',resave: false,saveUninitialized: true }));

