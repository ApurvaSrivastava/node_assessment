const mongoose=require('mongoose');
mongoose.connect('mongodb://localhost/university').
then(()=>console.log('connected to mongoose..')).
catch(err=>console.log('UNABLE TO CONNECT',err));

const info=new mongoose.Schema({
    name: String,
    age: Number,
    sid: Number
});
// async function createStu() {
  
//     const student=new Student({
//     name: 'meoww',
//     age: 23,
//     sid: 103
//     });
//     const result= await student.save();
//     console.log(result);
// }
//createStu();
const Student=new mongoose.model('Student',info);
async function getStudent() {
    const student=await Student.find();
    console.log(student);
}
getStudent();
